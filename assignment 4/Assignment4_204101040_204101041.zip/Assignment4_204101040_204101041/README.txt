For program 1:
	Compilation: g++ -o question1 question1.cpp -pthread
	Execution: ./question1

For program 2:
	Compilation: g++ -o question2 question2.cpp -pthread
	Execution: ./question2

For program 3:
	Compilation: g++ -o question3 question3.cpp -pthread
	Execution: ./question3

For program 4:
	Compilation: g++ -o question4 question4.cpp -pthread
	Execution: ./question4

Compiler used: linux gcc compiler

Group Candidates:
	1. Sanket Patil 204101041
	2. Pankaj Panwar 204101040